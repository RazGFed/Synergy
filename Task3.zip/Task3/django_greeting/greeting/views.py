from django.shortcuts import render

from .models import UserName


def index(request):
    greeting = ""
    error = ""

    if request.method == "POST":

        name = request.POST.get("name", "").strip()

        if not name:
            error = "Пожалуйста, введите ваше имя."

        elif len(name) > 100:
            error = "Имя не должно содержать более 100 символов."

        else:
            user_name = UserName.objects.create(name=name)

            greeting = f"Здравствуйте, {user_name.name}!"

    return render(
        request,
        "greeting/index.html",
        {
            "greeting": greeting,
            "error": error
        }
    )